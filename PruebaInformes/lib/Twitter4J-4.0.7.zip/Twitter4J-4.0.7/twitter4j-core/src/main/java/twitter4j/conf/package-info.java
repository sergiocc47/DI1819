/**
 * Twitter4J configurations
 */
package twitter4j.conf;