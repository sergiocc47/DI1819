/**
 * example codes for tweets resources
 */
package twitter4j.examples.tweets;