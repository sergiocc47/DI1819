/**
 * example codes for async API
 */
package twitter4j.examples.async;