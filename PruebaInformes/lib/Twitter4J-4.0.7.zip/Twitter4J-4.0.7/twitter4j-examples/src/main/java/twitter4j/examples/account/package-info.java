/**
 * example codes for account resources
 */
package twitter4j.examples.account;