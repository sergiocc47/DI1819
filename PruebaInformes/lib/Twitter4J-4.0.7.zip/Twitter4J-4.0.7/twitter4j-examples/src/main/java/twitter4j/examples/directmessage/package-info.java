/**
 * example codes for direct message resources
 */
package twitter4j.examples.directmessage;