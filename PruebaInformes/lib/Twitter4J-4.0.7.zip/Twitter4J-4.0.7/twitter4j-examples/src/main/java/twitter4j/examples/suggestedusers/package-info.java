/**
 * example codes for suggested users resources
 */
package twitter4j.examples.suggestedusers;