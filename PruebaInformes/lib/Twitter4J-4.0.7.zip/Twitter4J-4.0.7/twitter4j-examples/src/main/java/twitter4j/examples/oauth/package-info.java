/**
 * example code for OAuth dance
 */
package twitter4j.examples.oauth;